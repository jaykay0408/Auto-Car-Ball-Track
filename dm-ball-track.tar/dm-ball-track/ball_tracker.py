from picar import front_wheels, back_wheels, Servo
import picar
from time import sleep
import cv2
import numpy as np

picar.setup()
# Operational Options: Turn on = True, or Turn off = False
show_image_enable   = True	# Display video or Not
draw_circle_enable  = True	# Add a circle to display or Not
scan_enable         = False	# Search a ball surround or Not
rear_wheels_enable  = True	# Moving a car to chase a ball or Not
front_wheels_enable = True	# Steering a car to chase a ball or Not
pan_tilt_enable     = True	# Pan and tilt a camera or Not

#kernel = np.ones((5,5),np.uint8)	# Not used
img = cv2.VideoCapture(-1)		# Capture an image from a video

SCREEN_WIDTH = 160			# Captured image width
SCREEN_HIGHT = 120			# Captured image hight
img.set(3,SCREEN_WIDTH)
img.set(4,SCREEN_HIGHT)
CENTER_X = SCREEN_WIDTH/2
CENTER_Y = SCREEN_HIGHT/2
BALL_SIZE_MIN = SCREEN_HIGHT/12		# 10
BALL_SIZE_MAX = SCREEN_HIGHT/2		# 60

# Filter setting, DONOT CHANGE : Not used
#hmn = 12
#hmx = 37
#smn = 96
#smx = 255
#vmn = 186
#vmx = 255

# camera follow mode:
# 0 = step by step(slow, stable), i.e., every frame +- CAMERA_STEP
# 1 = calculate the step(fast, unstable), i.e., every frame +- difference
follow_mode = 0

CAMERA_STEP = 2				# Used for follow_mode = 0
CAMERA_X_ANGLE = 20			# # of pixcels per degree X
CAMERA_Y_ANGLE = 20			# # of pixcels per degree Y

MIDDLE_TOLERANT = 5			# Min error margin
PAN_ANGLE_MAX   = 170			# Max pan degree
PAN_ANGLE_MIN   = 10			# Min pan degree
TILT_ANGLE_MAX  = 150			# Max tilt degree
TILT_ANGLE_MIN  = 90			# Min tilt degree
FW_ANGLE_MAX    = 90+30			# Max steering left degree
FW_ANGLE_MIN    = 90-30			# Min steering right degree

SCAN_POS = [				# If ball size < MIN, i.e., no ball
           #[20, TILT_ANGLE_MIN], 	#    move a camera to search a ball
	    [50, TILT_ANGLE_MIN+20], 	#    one by one
	    [90, TILT_ANGLE_MIN+20], 
	    [130, TILT_ANGLE_MIN+20], 
           #[160, TILT_ANGLE_MIN], 
           #[160, 120], 
           # [130, 120], 
           # [90, 120], 
           # [50, 120], 
           #[20, 120]
           ]

bw = back_wheels.Back_Wheels()		# bw = backwheel servos
fw = front_wheels.Front_Wheels()	# fw = steering wheel servo
pan_servo = Servo.Servo(1)		# pan_servo = pan servo
tilt_servo = Servo.Servo(2)		# tilt_servo = tilt servo
picar.setup()

fw.offset = 0
pan_servo.offset = 10
tilt_servo.offset = 0

bw.speed = 0				# Car speed : 0 ~ 100
fw.turn(90)				# Move Steering wheel 90 : middle
pan_servo.write(90)			# Move Pan 90 : middle
tilt_servo.write(110)			# Move Tilt 110 : middle + 20

motor_speed = 40			# Car speed : 0 ~ 100

#def nothing(x):
#    pass

def main():
    pan_angle = 90              	# initial angle for pan
    tilt_angle = 90             	# initial angle for tilt
    fw_angle = 90			# initial angle for steering

    scan_count = 0
    print("Begin!")

    while True:
        x = 0             		# x initial in the middle
        y = 0             		# y initial in the middle
        r = 0             		# ball radius initial to 0
					# (no balls if r < ball_size)
        for i in range(10):
            (tmp_x, tmp_y), tmp_r = find_blob()
					# find_blob(): find circle and return
					# (tmp_x, tmp_y): origin of circle
					# tmp_r: radius
            if tmp_r > BALL_SIZE_MIN:
                x = tmp_x
                y = tmp_y
                r = tmp_r
                break

        print(x, y, r)

        # scan:
        if r < BALL_SIZE_MIN:			# no ball or too small ball
            bw.stop()
            if scan_enable:			# Scan the next position
                #bw.stop()
                pan_angle = SCAN_POS[scan_count][0]
                tilt_angle = SCAN_POS[scan_count][1]
                if pan_tilt_enable:
                    pan_servo.write(pan_angle)
                    tilt_servo.write(tilt_angle)
                scan_count += 1
                if scan_count >= len(SCAN_POS):
                    scan_count = 0
            else:
                sleep(0.1)
            
        elif r < BALL_SIZE_MAX:			# ball found
            if follow_mode == 0:		# Check ball position, 
						#   then pan/tilt by CAMERA_STEP
                if abs(x - CENTER_X) > MIDDLE_TOLERANT:
                    if x < CENTER_X:    # Ball is on left
                        pan_angle += CAMERA_STEP
                        #print "Left   ", 
                        if pan_angle > PAN_ANGLE_MAX:
                            pan_angle = PAN_ANGLE_MAX
                    else:               # Ball is on right
                        pan_angle -= CAMERA_STEP
                        #print "Right  ",
                        if pan_angle < PAN_ANGLE_MIN:
                            pan_angle = PAN_ANGLE_MIN
                if abs(y - CENTER_Y) > MIDDLE_TOLERANT:
                    if y < CENTER_Y :   # Ball is on top
                        tilt_angle += CAMERA_STEP
                        #print "Top    " 
                        if tilt_angle > TILT_ANGLE_MAX:
                            tilt_angle = TILT_ANGLE_MAX
                    else:               # Ball is on bottom
                        tilt_angle -= CAMERA_STEP
                        #print "Bottom "
                        if tilt_angle < TILT_ANGLE_MIN:
                            tilt_angle = TILT_ANGLE_MIN
            else:				# Check ball psoition,
						#   then pan/tilt by difference
                delta_x = CENTER_X - x
                delta_y = CENTER_Y - y
                #print "x = %s, delta_x = %s" % (x, delta_x)
                #print "y = %s, delta_y = %s" % (y, delta_y)
                delta_pan = int(float(CAMERA_X_ANGLE) / SCREEN_WIDTH * delta_x)
                #print "delta_pan = %s" % delta_pan
                pan_angle += delta_pan
                delta_tilt = int(float(CAMERA_Y_ANGLE) / SCREEN_HIGHT * delta_y)
                #print "delta_tilt = %s" % delta_tilt
                tilt_angle += delta_tilt

                if pan_angle > PAN_ANGLE_MAX:
                    pan_angle = PAN_ANGLE_MAX
                elif pan_angle < PAN_ANGLE_MIN:
                    pan_angle = PAN_ANGLE_MIN
                if tilt_angle > TILT_ANGLE_MAX:
                    tilt_angle = TILT_ANGLE_MAX
                elif tilt_angle < TILT_ANGLE_MIN:
                    tilt_angle = TILT_ANGLE_MIN
            
            if pan_tilt_enable:			# Move a camera
                pan_servo.write(pan_angle)
                tilt_servo.write(tilt_angle)
            sleep(0.01)
            fw_angle = 180 - pan_angle
            if fw_angle < FW_ANGLE_MIN or fw_angle > FW_ANGLE_MAX:
                fw_angle = ((180 - fw_angle) - 90)/2 + 90
                if front_wheels_enable:
                    fw.turn(fw_angle)
                if rear_wheels_enable:
                    bw.speed = motor_speed
                    bw.backward()
            else:
                if front_wheels_enable:
                    fw.turn(fw_angle)
                if rear_wheels_enable:
                    bw.speed = motor_speed
                    bw.forward()
        else:					# ball is too big (= too close)
            bw.stop()
        
def destroy():
    bw.stop()
    img.release()

#def test():
#    fw.turn(90)

def find_blob() :
    radius = 0
    # Load input image
    _, bgr_image = img.read()			# Capture a frame

    orig_image = bgr_image

    bgr_image = cv2.medianBlur(bgr_image, 3)	# Blur an image

    # Convert input image to HSV
    hsv_image = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2HSV)

    # Threshold the HSV image, keep only the red pixels
    lower_red_hue_range = cv2.inRange(hsv_image, (0, 100, 100), (10, 255, 255))
    upper_red_hue_range = cv2.inRange(hsv_image, (160, 100, 100), (179, 255, 255))
    # Combine the above two images
    red_hue_image = cv2.addWeighted(lower_red_hue_range, 1.0, upper_red_hue_range, 1.0, 0.0)
    yellow_hue_image = cv2.inRange(hsv_image, (20, 50, 50), (70, 255, 255))

    red_hue_image = cv2.GaussianBlur(yellow_hue_image, (5, 5), 2, 2)
    #red_hue_image = cv2.erode(red_hue_image, None, iterations=2)
    #red_hue_image = cv2.dilate(red_hue_image, None, iterations=2)

    # Use the Hough transform to detect circles in the combined threshold image
    circles = cv2.HoughCircles(red_hue_image, cv2.HOUGH_GRADIENT, 
				dp=1, 			# dp = 1
				minDist=120, 		# minDist = 120
				param1=100, 		# Para 1 = 100
				param2=20, 		# Para 2 = 20
				minRadius=10, 		# min Radius = 10
				maxRadius=0);		# max Radius = 0


    # Loop over all detected circles and outline them on the original image
    all_r = np.array([])
    if circles is not None and len(circles) !=4:
    #if circles is not None:
        for i in circles[0]:
            all_r = np.append(all_r, int(round(i[2])))
        closest_ball = all_r.argmax()
        center=(int(round(circles[0][closest_ball][0])), int(round(circles[0][closest_ball][1])))
        radius=int(round(circles[0][closest_ball][2]))
        if draw_circle_enable:
            cv2.circle(orig_image, center, radius, (0, 255, 0), 5);

    # Show images
    if show_image_enable:
        #cv2.namedWindow("Threshold lower image", cv2.WINDOW_AUTOSIZE)
        #cv2.imshow("Threshold lower image", lower_red_hue_range)
        #cv2.namedWindow("Threshold upper image", cv2.WINDOW_AUTOSIZE)
        #cv2.imshow("Threshold upper image", upper_red_hue_range)
        cv2.namedWindow("Combined threshold images", cv2.WINDOW_AUTOSIZE)
        cv2.imshow("Combined threshold images", red_hue_image)

        cv2.namedWindow("Yellow hue image", cv2.WINDOW_AUTOSIZE)
        cv2.imshow("Yellow hue image", yellow_hue_image)

        cv2.namedWindow("Detected red circles on the input image", cv2.WINDOW_AUTOSIZE)
        cv2.imshow("Detected red circles on the input image", orig_image)

    k = cv2.waitKey(5) & 0xFF
    if k == 27:				# ESC key
        return (0, 0), 0
    if radius > 3:
        return center, radius;
    else:
        return (0, 0), 0


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        destroy()
